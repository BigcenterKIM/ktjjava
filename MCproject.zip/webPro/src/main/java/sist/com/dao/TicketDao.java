package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import sist.com.bean.TicketBean;
import sist.com.bean.TorderBean;

public class TicketDao extends SqlSessionDaoSupport{
	
	public void updateSeat(String tcode, String tseat) {
		HashMap<String, String> map=new HashMap<String, String>();
		map.put("tcode", tcode);
		map.put("tseat", tseat);
		this.getSqlSession().update("updateSeat", map);
	}
	
	@Transactional
	public void insertTorder(TorderBean bean) {
		this.getSqlSession().insert("insertTorder", bean);
	}
	
	public String selectTocode() {
		return this.getSqlSession().selectOne("selectTocode");
	}
	
	public List<String> selectSoldSeat(String tcode){
		return this.getSqlSession().selectList("selectSoldSeat", tcode);
	}
	
	public Object selectTicketByCode(String tcode) {
		return this.getSqlSession().selectOne("selectTicketByCode", tcode);
	}
	
	public String selectTcname(String tccode) {
		return this.getSqlSession().selectOne("selectTcname", tccode);
	}
	
	public List<TicketBean> selectTicketByTCategory(String tccode){
		return this.getSqlSession().selectList("selectTicketByTCategory", tccode);
	}
	
	public List<TicketBean> selectAllTicket(){
		return this.getSqlSession().selectList("selectAllTicket");
	}

}
