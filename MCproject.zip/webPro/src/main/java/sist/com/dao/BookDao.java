package sist.com.dao;

import java.util.HashMap;
import java.util.List;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import sist.com.bean.BookBean;
import sist.com.bean.BorderBean;

public class BookDao extends SqlSessionDaoSupport{
	
	public String selectScname(String sccode) {
		return this.getSqlSession().selectOne("selectScname", sccode);
	}
	
	public String selectLcname(String lccode) {
		return this.getSqlSession().selectOne("selectLcname", lccode);
	}
	
	public List<BookBean> selectBookByCategory(String lccode, String sccode){
		HashMap<String, String> map=new HashMap<String, String>();
		map.put("lccode", lccode);
		map.put("sccode", sccode);
		return this.getSqlSession().selectList("selectBookByCategory", map);
	}
	public BookBean selectBookByCode(String bcode) {
		return this.getSqlSession().selectOne("selectBookByCode", bcode);
	}
	public void insertBorder(BorderBean bean) { // BORDER 테이블 구매정보 삽입
			this.getSqlSession().insert("insertBorder",bean);
	}
}