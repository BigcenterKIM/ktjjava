package sist.com.dao;

import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.WishListBean;

public class WishListDao extends SqlSessionDaoSupport  {
	
	public int addBookToCart(WishListBean wish) {
		return this.getSqlSession().insert("addBookToCart",wish);
	}
	
	public List<WishListBean> showCartList(String wcode) {
		return this.getSqlSession().selectList("showCartList",wcode);
	}
	public int deleteBookFromCart(WishListBean wish) {
		return this.getSqlSession().delete("deleteBookFromCart", wish);
	}
	public int modifyBookQtyFromCart(WishListBean wish) {
		return this.getSqlSession().update("modifyBookQtyFromCart",wish);
	}
	public boolean isExist(WishListBean wish) {
		return this.getSqlSession().selectOne("isExist", wish) != null?true:false;
	}
	
}
