package sist.com.dao;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import sist.com.bean.CustomerBean;
import sist.com.bean.TorderBean;
import sist.com.bean.ZipcodeBean;

public class CustomerDao extends SqlSessionDaoSupport{
	
	public List<TorderBean> selectTorderList(String cid){
		return this.getSqlSession().selectList("selectTorderList", cid);
	}
	
	public void updatePoint(String cid, int point) {
		HashMap<String, Object> map=new HashMap<String, Object>();
		map.put("cid", cid);
		map.put("point", point);
		this.getSqlSession().update("updatePoint", map);
	}
	
	public ZipcodeBean selectZipcode(String seq) {
		return this.getSqlSession().selectOne("selectZipcode", seq);
	}
	
	public String selectGname(String gcode) {
		return this.getSqlSession().selectOne("selectGname", gcode);
	}
	
	public CustomerBean selectCustomer(String cid) {
		return this.getSqlSession().selectOne("selectCustomer", cid);
	}
	
	public String loginCheck(String cid) {
		return this.getSqlSession().selectOne("loginCheck", cid);
	}
	
//	�룄�꽌 寃곗젣愿��젴�뿉 �궗�슜�릺�뒗 DAO
	public String getWcode(String cid) {
		return this.getSqlSession().selectOne("getWcode",cid);
	}
	public int getPoint(String cid) {
		return this.getSqlSession().selectOne("getPoint",cid);
	}
	public void usePoint(CustomerBean bean) { // 留덉씪由ъ� 李④컧�슜 DAO
		   this.getSqlSession().update("usePoint", bean);
	   }
	
	public void insertCustomer(CustomerBean bean) { // int�� string 媛숈씠�엳�뼱�꽌 �옄袁� �삎 留욎텛�씪�븿 > object濡� 諛뺤븘踰꾨┝
		this.getSqlSession().insert("insertCustomer",bean);
	}
	public CustomerBean idCheck(CustomerBean bean) {
		return this.getSqlSession().selectOne("idCheck",bean);
	} //�븘�씠�뵒 以묐났泥댄겕
	public List<ZipcodeBean> selectZipcodeByDong(String dong){
		return this.getSqlSession().selectList("selectZipcodeByDong", dong);
	}
	
	/*TJ's code*/
	public Object selectcustomerInfo(String cid){
		return this.getSqlSession().selectOne("selectcustomerInfo", cid);
	}
	public ZipcodeBean getZipcode(String seq) {
		return this.getSqlSession().selectOne("getZipcode", seq);
	}

	public String getGname(String gcode) {
		return this.getSqlSession().selectOne("getGname", gcode);
	}
	
	public List<CustomerBean> selectBorder(String cid) {
		return this.getSqlSession().selectList("selectBorder",cid);
	}
	public List<CustomerBean> selectBorder2(String cid) {
		return this.getSqlSession().selectList("selectBorder2",cid);
	}
	
	/*//TJ's code*/
	
}
