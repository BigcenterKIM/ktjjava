package sist.com.web;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import sist.com.bean.CustomerBean;
import sist.com.bean.TorderBean;
import sist.com.bean.ZipcodeBean;
import sist.com.dao.BookDao;
import sist.com.dao.CustomerDao;
import sist.com.dao.WishListDao;

@Controller
public class CustomerController {
	
	@Resource(name="bookDao")
	BookDao bdao;
	
	@Resource(name="wishListDao")
	WishListDao wishDao;
	
	@Resource(name="customerDao")
	CustomerDao dao;

	@RequestMapping(value = "myPage.do")
	public String myPage(@RequestParam(value = "cid") String cid, Model model) {
		CustomerBean customer = dao.selectCustomer(cid);
		model.addAttribute("info", dao.selectcustomerInfo(cid));/*TJ's code*/
		model.addAttribute("border", dao.selectBorder(cid));/*TJ's code*/
		model.addAttribute("border2", dao.selectBorder2(cid));/*TJ's code*/
		model.addAttribute("wList", wishDao.showCartList(dao.getWcode(cid)));/*TJ's code*/
		model.addAttribute("customer", customer);
		model.addAttribute("gname", dao.selectGname(customer.getGcode()));
		ZipcodeBean zipcode = dao.selectZipcode(customer.getSeq());
		model.addAttribute("zipcode", zipcode);
		List<TorderBean> tList=dao.selectTorderList(cid);
		model.addAttribute("tList", tList);
		return "layout/myPage";
	}

	@RequestMapping(value = "logOut.do")
	public String logOut(HttpSession session) {
		session.invalidate();
		return "redirect:/layout/main.jsp";
	}

	@RequestMapping(value = "login.do")
	public String loginProcess(String cid, String cpw, HttpSession session) {
		String realPw = dao.loginCheck(cid);
		if (cpw.equals(realPw)) {
			session.setAttribute("login", "t");
			session.setAttribute("cid", cid);
			session.setAttribute("member",dao.selectCustomer(cid));
			
			return "redirect:/layout/main.jsp";
		} else {
			return "redirect:/layout/login.jsp?login=f";
		}
	}
	
	@RequestMapping(value = "join.do")
	public String insertCustomer(CustomerBean bean) {
		Date today=new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String year=sdf.format(today).substring(0, 4);
		System.out.println("this year : "+year);
		bean.setAge(Integer.parseInt(year)-Integer.parseInt(bean.getBirthDate().substring(0, 4)));
		dao.insertCustomer(bean);
		return "redirect:/layout/login.jsp";
	}

	@RequestMapping(value = "selectZipcode.do")
	public String searchZipcode(String dong, Model model) {
		System.out.println("dong : "+dong);
		List<ZipcodeBean> list=dao.selectZipcodeByDong(dong);
		model.addAttribute("list", list);
		return "layout/address";
	}
	
	/*TJ's code*/
	@RequestMapping(value="customerinfo.do")
	public String infoProcess(Model model, String cid,String seq,String gcode) {
		model.addAttribute("info", dao.selectcustomerInfo(cid));
		model.addAttribute("border", dao.selectBorder(cid));
		return "layout/myPage";
	}
	@RequestMapping(value="bookOrder.do")
	public String infoProcess2(Model model, String cid,String bocode,String seq,String gcode) {
		model.addAttribute("border2", dao.selectBorder2(cid));
		return "layout/bookOrder";
	}
	/*//TJ's code*/
	
}
