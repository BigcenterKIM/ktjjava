package sist.com.web;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import sist.com.bean.BookBean;
import sist.com.bean.BorderBean;
import sist.com.bean.CustomerBean;
import sist.com.bean.WishListBean;
import sist.com.dao.BookDao;
import sist.com.dao.CustomerDao;
import sist.com.dao.WishListDao;

@Controller
public class BookController {

	@Resource(name="bookDao")
	BookDao dao;
	
	@Resource(name="wishListDao")
	WishListDao wishDao;
	
	@Resource(name="customerDao")
	CustomerDao custDao;
	
	@RequestMapping(value = "bookList.do")
	public String bookList(@RequestParam(value = "lccode", required = false) String lccode,
							@RequestParam(value = "sccode", required = false) String sccode, 
							Model model) {
		List<BookBean> list=null;
		model.addAttribute("lccode", lccode);
		model.addAttribute("sccode", sccode);
		list=dao.selectBookByCategory(lccode, sccode);
		model.addAttribute("list", list);
		if(lccode!=null) {
			String lcname=dao.selectLcname(lccode);
			model.addAttribute("lcname", lcname);
		}
		if(sccode!=null) {
			String scname=dao.selectScname(sccode);
			model.addAttribute("scname", scname);
		}
		return "/layout/bookList";
	}
	
	@RequestMapping(value = "bookInfo.do")
	public String bookInfo(HttpSession session,
			@RequestParam(value="bcode")String bcode,
			@RequestParam(value="fail",required=false)String fail, 
			Model model) {
		BookBean bean=(BookBean)dao.selectBookByCode(bcode);
		String cid=(String)session.getAttribute("cid");
		String wcode=custDao.getWcode(cid);
		String resultMsg = ""; 
		model.addAttribute("bean", bean);
		model.addAttribute("contents", bean.getBpreview().replaceAll("\\\\r\\\\n", "<br>"));
		if(fail.equals("true")) {  //장바구니 중복항목으로 인해 추가에 실패하여 돌아왔을때
			resultMsg += "<script>"; 
			resultMsg += "alert('해당 상품은 이미 카트에 보관되어 있습니다.');";	
			resultMsg += "if(confirm('장바구니로 이동 하시겠습니까?')==true){";
			resultMsg += "location.href='/webPro/beforeNewCart.do?fail=true&login=t&wcode="+wcode+"';}";
			resultMsg += "</script>"; 
			model.addAttribute("result",resultMsg);
		}else {
			return "/layout/bookInfo";
		}
			return "/layout/bookInfo";
	}
	
	@RequestMapping(value="beforeNewCart.do") 
	public String beforeNewCart(Model model,HttpSession session,
			@RequestParam(value="bcode",required=false)String bcode,
			@RequestParam(value="bprice",required=false) String bprice,
			@RequestParam(value="bqty",required=false)String bqty,
			@RequestParam(value="fail",required=false)String fail) {
		
		String cid=(String)session.getAttribute("cid");
		String wcode=custDao.getWcode(cid);
		
		fail=fail==null?"null":fail;							// null로 들어올때 처리
		int wamount=Integer.parseInt(bqty==null?"0":bqty);		// null로 들어올때 처리
		int wiprice=Integer.parseInt(bprice==null?"0":bprice);	// null로 들어올때 처리

		WishListBean wish=new WishListBean();		
		wish.setBcode(bcode);
		wish.setWcode(wcode);
		wish.setWamount(wamount);
		
		if(fail.equals("true")) { // 이미 해당 도서가 장바구니에 존재하는데도 장바구니로 갈 경우
			List<WishListBean> list=wishDao.showCartList(wcode);
			model.addAttribute("list", list);
			return "/layout/newCart";
		}
		else if(wishDao.isExist(wish)==true){ // 이미 해당 도서가 장바구니에 존재하는 경우 
			return "redirect:bookInfo.do?fail=true&bcode="+bcode;
		}else{
			wishDao.addBookToCart(wish);  // 장바구니에 새 도서 추가
			List<WishListBean> list=wishDao.showCartList(wcode);
			model.addAttribute("list", list);
			return "/layout/newCart";
		}
	}
	
	@RequestMapping(value="delCartItem.do")
	public String delCartItem(Model model,String bcode,String wcode) {
		
		WishListBean wish=new WishListBean();		
		wish.setBcode(bcode.trim());
		wish.setWcode(wcode.trim());
		wishDao.deleteBookFromCart(wish);
		
		List<WishListBean> list=wishDao.showCartList(wcode);
		model.addAttribute("list", list);
		
		return "/layout/newCart";
	}
	
	@RequestMapping(value="modifyBookQtyFromCart.do")
	public String modifyBookQtyFromCart(Model model,String wcode,String bcode,int wamount) {
		WishListBean wish=new WishListBean();
		wish.setWcode(wcode);
		wish.setBcode(bcode);
		wish.setWamount(wamount);
		System.out.println(wish);
		wishDao.modifyBookQtyFromCart(wish);
		
		List<WishListBean> list=wishDao.showCartList(wcode);
		model.addAttribute("list", list);
		
		return "/layout/newCart";
	}
	
	@RequestMapping(value="beforePayment.do")
	public String beforePayment(HttpSession session,String job,
			@RequestParam(value="bimage",required=false)String bimage,
			@RequestParam(value="wamount",required=false)String wamount,
			@RequestParam(value="bname",required=false)String bname,
			@RequestParam(value="wiprice",required=false)String wiprice,
			@RequestParam(value="bcode",required=false)String bcode,
			Model model) {
		
		if(job.equals("all")) { //전체구매시
			String cid=(String)session.getAttribute("cid");
			String wcode=custDao.getWcode(cid);
			List<WishListBean> list=wishDao.showCartList(wcode);
			session.setAttribute("payList", list); 
			session.setAttribute("cid", cid);
			model.addAttribute("checker","all");
			return "/layout/newPayment";
			
		}else if(job.equals("one")) { //바로구매시
			String cid=(String)session.getAttribute("cid");
			String wcode=custDao.getWcode(cid);
			WishListBean bean=new WishListBean();
			bean.setBimage(bimage);
			bean.setWamount(Integer.parseInt(wamount));
			bean.setBname(bname);
			bean.setBcode(bcode);
			bean.setBprice(Integer.parseInt(wiprice));
			session.setAttribute("payOne", bean);
			model.addAttribute("checker","one");
			return "/layout/newPayment";
		}
		return "";
	}
	
	@RequestMapping(value="afterPayment.do")
	public String afterPayment(Model model,HttpSession session,String job) {
		//BOCODE, CID, BCODE, BAMOUNT;
		ArrayList<WishListBean> list=new ArrayList<WishListBean>();
		int boprice=0;
		int bopoint=0;
		int boupoint=0;
		int newPoint=0; // 마일리지 차감 후 재반영할 포인트
		String cid=(String)session.getAttribute("cid");
		int point=custDao.getPoint(cid); // 현재 보유포인트
		
		if (job.equals("all")) {
			list=(ArrayList)session.getAttribute("payList");
		}else {
			list.add((WishListBean)session.getAttribute("payOne"));
		}
		
		for(int i=0;i<list.size();i++){ //결제목록에 있는 도서금액 총합
			boprice+=list.get(i).getBprice()*0.9*list.get(i).getWamount(); //할인율 조정 구현 필요
		}
		
		CustomerBean customer=new CustomerBean();
		
		if(point>boprice){ // 보유 마일리지가 구매금액보다 커서 결제가 가능한 경우
			
			for(int j=0;j<list.size();j++){  // BORDER 테이블에 결제정보 등록
				BorderBean bean=new BorderBean();
				bean.setCid(cid);
				bean.setBcode(list.get(j).getBcode());
				bean.setBamount(list.get(j).getWamount());
				dao.insertBorder(bean);
			}
			
			if(boprice<50000){  //50000 원 미만 결제시 배송료 부가 조건문
				boprice=boprice+2500; 	// 결제목록에 있는 도서금액의 총합을 구매금액으로 설정 + 배송비
				}
			
			newPoint=point-boprice; //사용한 마일리지 차감
			customer.setPoint(newPoint+(int)(boprice*0.05)); //차감 후 남은 포인트 + 구매로 인한 적립금
			customer.setCid(cid);
			custDao.usePoint(customer); // 사용한 마일리지를 고객정보에 반영

			session.setMaxInactiveInterval(0); // 결제창 초기화를 위한 세션초기화 
			session.setAttribute("cid", cid); // 로그인 정보 세션 재설정  
			
			for(int k=0;k<list.size();k++){ // 결제 성공 전 결제 될 아이템들은 장바구니에서 삭제
				WishListBean wishbean=new WishListBean();
				wishbean.setBcode(list.get(k).getBcode());
				wishbean.setWcode(custDao.getWcode(cid));
				wishDao.deleteBookFromCart(wishbean);
				session.setAttribute("member",custDao.selectCustomer(cid));
				}
			return "/layout/paymentSuccess";
			
		}else{
			String resultMsg = "";  //마일리지 잔액이 부족하여 결제가 불가능 한 경우
			resultMsg += "<script>"; 
			resultMsg += "alert('마일리지 잔액이 부족하여 결제가 불가능합니다.');";
			resultMsg += "</script>"; 
			model.addAttribute("result",resultMsg);
			if (job.equals("all")) {
				model.addAttribute("checker","all");
			}else {
				model.addAttribute("checker","one");
			}
			return "/layout/newPayment";
		}
	}

}
