package sist.com.web;

import java.util.List;
import java.util.Vector;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import sist.com.bean.CustomerBean;
import sist.com.bean.TicketBean;
import sist.com.bean.TorderBean;
import sist.com.dao.CustomerDao;
import sist.com.dao.TicketDao;

@Controller
public class TicketController {

	@Inject
	TicketDao dao;
	
	@Inject
	CustomerDao customerDao;

	@RequestMapping(value = "ticketOrderProcess.do")
	public String ticketOrderProcess(@RequestParam(value = "cid") String cid,
			@RequestParam(value = "tcode") String tcode, @RequestParam(value = "tseats") String tseats,
			@RequestParam(value = "amount") int amount, @RequestParam(value="point")String point) {
		Vector<String> vector = new Vector<String>();
		TorderBean torderBean = new TorderBean();
		synchronized (dao) {
			torderBean.setTocode(dao.selectTocode());
			for (int i = 0; i < amount; i++) {
				vector.add(tseats.trim().split(",")[i].trim());
				torderBean.setCid(cid);
				torderBean.setTcode(tcode);
				torderBean.setTseat(vector.get(i));
				dao.insertTorder(torderBean);
				dao.updateSeat(tcode, torderBean.getTseat());
			}
		}
		CustomerBean customer=customerDao.selectCustomer(cid);
		int p=Integer.parseInt(point.substring(0, point.indexOf(".")))+customer.getPoint();
		customerDao.updatePoint(cid, p);
		return "redirect:/layout/paymentSuccess.jsp?cid="+cid;
	}

	@RequestMapping(value = "ticketOrder.do")
	public String ticketOrder(@RequestParam(value = "tcode") String tcode, @RequestParam(value = "amount") int amount,
			Model model) {
		TicketBean bean = (TicketBean) dao.selectTicketByCode(tcode);
		model.addAttribute("bean", bean);
		model.addAttribute("amount", amount);
		List<String> soldList = dao.selectSoldSeat(tcode);
		if (!(soldList.isEmpty())) {
			model.addAttribute("soldList", soldList);
		}
		return "layout/ticketOrder";
	}

	@RequestMapping(value = "ticketInfo.do")
	public String ticketInfo(@RequestParam(value = "tcode") String tcode, Model model) {
		TicketBean bean = (TicketBean) dao.selectTicketByCode(tcode);
		model.addAttribute("bean", bean);
		model.addAttribute("contents", bean.getTpreview().replaceAll("\\\\r\\\\n", "<br>"));
		return "layout/ticketInfo";
	}

	@RequestMapping(value = "ticketList.do")
	public String ticketList(@RequestParam(value = "tccode", required = false) String tccode, Model model) {
		List<TicketBean> list = null;
		model.addAttribute("tccode", tccode);
		if (tccode == null) {
			list = dao.selectAllTicket();
			model.addAttribute("list", list);
			System.out.println(list.get(0));
		} else {
			list = dao.selectTicketByTCategory(tccode);
			model.addAttribute("list", list);
			String tcname = dao.selectTcname(tccode);
			model.addAttribute("tcname", tcname);
			System.out.println(tcname);
		}
		return "layout/ticketList";
	}
}
