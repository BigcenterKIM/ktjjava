package sist.com.bean;

public class BorderBean {
	//BOCODE, CID, BCODE, BAMOUNT, REGDATE
	private String bocode;
	private String cid;
	private String bcode;
	private int bamount;
	private String regdate;
	public String getBocode() {
		return bocode;
	}
	public void setBocode(String bocode) {
		this.bocode = bocode;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getBcode() {
		return bcode;
	}
	public void setBcode(String bcode) {
		this.bcode = bcode;
	}
	public int getBamount() {
		return bamount;
	}
	public void setBamount(int bamount) {
		this.bamount = bamount;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	@Override
	public String toString() {
		return "BorderBean [bocode=" + bocode + ", cid=" + cid + ", bcode=" + bcode + ", bamount=" + bamount
				+ ", regdate=" + regdate + "]";
	}
	
}
