package sist.com.bean;

public class TorderBean {
	//TOCODE, CID, TCODE, TSEAT, REGDATE
	private String tocode;
	private String cid;
	private String tcode;
	private String tseat;
	private String regdate;
	public String getTocode() {
		return tocode;
	}
	public void setTocode(String tocode) {
		this.tocode = tocode;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getTcode() {
		return tcode;
	}
	public void setTcode(String tcode) {
		this.tcode = tcode;
	}
	public String getTseat() {
		return tseat;
	}
	public void setTseat(String tseat) {
		this.tseat = tseat;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	@Override
	public String toString() {
		return "TorderBean [tocode=" + tocode + ", cid=" + cid + ", tcode=" + tcode + ", tseat=" + tseat + ", regdate="
				+ regdate + "]";
	}
	
}
