package sist.com.bean;

public class WishListBean {
	private String wcode;
	private String bcode;
	private int wamount;
	private String bname;
	private String bimage;
	private int bprice;
	
	public String getWcode() {
		return wcode;
	}
	public void setWcode(String wcode) {
		this.wcode = wcode;
	}
	public String getBcode() {
		return bcode;
	}
	public void setBcode(String bcode) {
		this.bcode = bcode;
	}
	public int getWamount() {
		return wamount;
	}
	public void setWamount(int wamount) {
		this.wamount = wamount;
	}
	@Override
	public String toString() {
		return "WishListBean [wcode=" + wcode + ", bcode=" + bcode + ", wamount=" + wamount + "]";
	}
	public String getBimage() {
		return bimage;
	}
	public void setBimage(String bimage) {
		this.bimage = bimage;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public int getBprice() {
		return bprice;
	}
	public void setBprice(int bprice) {
		this.bprice = bprice;
	}
	
}
