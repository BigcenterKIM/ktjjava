package sist.com.bean;

public class TicketBean {
	//TCODE, TNAME, TIMAGE, TPREVIEW, TLOC, TCCODE, TPRICE, TCOST, TSTOCK, TDATE, TLASTDATE
	private String tcode;
	private String tname;
	private String timage;
	private String tpreview;
	private String tloc;
	private String tccode;
	private int tprice;
	private int tstock;
	private String tdate;
	private String tlastDate;
	public String getTcode() {
		return tcode;
	}
	public void setTcode(String tcode) {
		this.tcode = tcode;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTimage() {
		return timage;
	}
	public void setTimage(String timage) {
		this.timage = timage;
	}
	public String getTpreview() {
		return tpreview;
	}
	public void setTpreview(String tpreview) {
		this.tpreview = tpreview;
	}
	public String getTloc() {
		return tloc;
	}
	public void setTloc(String tloc) {
		this.tloc = tloc;
	}
	public String getTccode() {
		return tccode;
	}
	public void setTccode(String tccode) {
		this.tccode = tccode;
	}
	public int getTprice() {
		return tprice;
	}
	public void setTprice(int tprice) {
		this.tprice = tprice;
	}
	public int getTstock() {
		return tstock;
	}
	public void setTstock(int tstock) {
		this.tstock = tstock;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getTlastDate() {
		return tlastDate;
	}
	public void setTlastDate(String tlastDate) {
		this.tlastDate = tlastDate;
	}
	@Override
	public String toString() {
		return "TicketBean [tcode=" + tcode + ", tname=" + tname + ", timage=" + timage + ", tpreview=" + tpreview
				+ ", tloc=" + tloc + ", tccode=" + tccode + ", tprice=" + tprice + ", tstock=" + tstock + ", tdate="
				+ tdate + ", tlastDate=" + tlastDate + "]";
	}

}
