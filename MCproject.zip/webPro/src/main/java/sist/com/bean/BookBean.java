package sist.com.bean;

public class BookBean {
	//BCODE, BNAME, BIMAGE, LCCODE, SCCODE, BWRITER, BPREVIEW, BPCODE, BPRICE, BCOST, BSTOCK
	private String bcode;
	private String bname;
	private String bimage;
	private String lccode;
	private String sccode;
	private String bwriter;
	private String bpreview;
	private String bpcode;
	private int bprice;
	private int bcost;
	private int bstock;
	public String getBcode() {
		return bcode;
	}
	public void setBcode(String bcode) {
		this.bcode = bcode;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBimage() {
		return bimage;
	}
	public void setBimage(String bimage) {
		this.bimage = bimage;
	}
	public String getLccode() {
		return lccode;
	}
	public void setLccode(String lccode) {
		this.lccode = lccode;
	}
	public String getSccode() {
		return sccode;
	}
	public void setSccode(String sccode) {
		this.sccode = sccode;
	}
	public String getBwriter() {
		return bwriter;
	}
	public void setBwriter(String bwriter) {
		this.bwriter = bwriter;
	}
	public String getBpreview() {
		return bpreview;
	}
	public void setBpreview(String bpreview) {
		this.bpreview = bpreview;
	}
	public String getBpcode() {
		return bpcode;
	}
	public void setBpcode(String bpcode) {
		this.bpcode = bpcode;
	}
	public int getBprice() {
		return bprice;
	}
	public void setBprice(int bprice) {
		this.bprice = bprice;
	}
	public int getBcost() {
		return bcost;
	}
	public void setBcost(int bcost) {
		this.bcost = bcost;
	}
	public int getBstock() {
		return bstock;
	}
	public void setBstock(int bstock) {
		this.bstock = bstock;
	}
	@Override
	public String toString() {
		return "BookBean [bcode=" + bcode + ", bname=" + bname + ", bimage=" + bimage + ", lccode=" + lccode
				+ ", sccode=" + sccode + ", bwriter=" + bwriter + ", bpreview=" + bpreview + ", bpcode=" + bpcode
				+ ", bprice=" + bprice + ", bcost=" + bcost + ", bstock=" + bstock + "]";
	}

}
