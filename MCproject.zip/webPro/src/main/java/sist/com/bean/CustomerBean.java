package sist.com.bean;

public class CustomerBean {
	//CID, CPW, CNAME, AGE, BIRTHDATE, GENDER, SEQ, GCODE, POINT, WCODE, JDATE
	private String cid;
	private String cpw;
	private String cname;
	private int age;
	private String birthDate;
	private String gender;
	private String seq;
	private String gcode;
	private int point;
	private String wcode;
	private String jdate;
	private String gname;
	private String sido;
	private String gugun;
	private String dong;
	private String bcode;
	
	private String bocode;
	private String regdate;
	private String bname;
	private String bamount;
	private int bprice;
	private int aprice;
	
	public int getAprice() {
		return aprice;
	}
	public void setAprice(int aprice) {
		this.aprice = aprice;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBamount() {
		return bamount;
	}
	public void setBamount(String bamount) {
		this.bamount = bamount;
	}
	public int getBprice() {
		return bprice;
	}
	public void setBprice(int bprice) {
		this.bprice = bprice;
	}
	public String getBcode() {
		return bcode;
	}
	public void setBcode(String bcode) {
		this.bcode = bcode;
	}
	public String getBocode() {
		return bocode;
	}
	public void setBocode(String bocode) {
		this.bocode = bocode;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getSido() {
		return sido;
	}
	public void setSido(String sido) {
		this.sido = sido;
	}
	public String getGugun() {
		return gugun;
	}
	public void setGugun(String gugun) {
		this.gugun = gugun;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCpw() {
		return cpw;
	}
	public void setCpw(String cpw) {
		this.cpw = cpw;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getGcode() {
		return gcode;
	}
	public void setGcode(String gcode) {
		this.gcode = gcode;
	}
	public int getPoint() {
		return point;
	}
	public void setPoint(int point) {
		this.point = point;
	}
	public String getWcode() {
		return wcode;
	}
	public void setWcode(String wcode) {
		this.wcode = wcode;
	}
	public String getJdate() {
		return jdate;
	}
	public void setJdate(String jdate) {
		this.jdate = jdate;
	}
	@Override
	public String toString() {
		return "CustomerBean [cid=" + cid + ", cpw=" + cpw + ", cname=" + cname + ", age=" + age + ", birthDate="
				+ birthDate + ", gender=" + gender + ", seq=" + seq + ", gcode=" + gcode + ", point=" + point
				+ ", wcode=" + wcode + ", jdate=" + jdate + ", gname=" + gname + ", sido=" + sido + ", gugun=" + gugun
				+ ", dong=" + dong + ", bcode=" + bcode + ", bocode=" + bocode + ", regdate=" + regdate + ", bname="
				+ bname + ", bamount=" + bamount + ", bprice=" + bprice + ", aprice=" + aprice + "]";
	}
	
	
}
