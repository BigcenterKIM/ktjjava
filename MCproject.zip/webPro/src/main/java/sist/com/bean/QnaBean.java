package sist.com.bean;

public class QnaBean {
//	QNO, QWRITER, QTITLE, QCCODE, QHIT, QUESTION, ANSWER, QDATE
	private int qno;
	private String qwriter;
	private String qtitle;
	private String qccode;
	private int qhit;
	private String question;
	private String answer;
	private String qdate;
	public int getQno() {
		return qno;
	}
	public void setQno(int qno) {
		this.qno = qno;
	}
	public String getQwriter() {
		return qwriter;
	}
	public void setQwriter(String qwriter) {
		this.qwriter = qwriter;
	}
	public String getQtitle() {
		return qtitle;
	}
	public void setQtitle(String qtitle) {
		this.qtitle = qtitle;
	}
	public String getQccode() {
		return qccode;
	}
	public void setQccode(String qccode) {
		this.qccode = qccode;
	}
	public int getQhit() {
		return qhit;
	}
	public void setQhit(int qhit) {
		this.qhit = qhit;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getQdate() {
		return qdate;
	}
	public void setQdate(String qdate) {
		this.qdate = qdate;
	}
	@Override
	public String toString() {
		return "QnaBean [qno=" + qno + ", qwriter=" + qwriter + ", qtitle=" + qtitle + ", qccode=" + qccode + ", qhit="
				+ qhit + ", question=" + question + ", answer=" + answer + ", qdate=" + qdate + "]";
	}

}
